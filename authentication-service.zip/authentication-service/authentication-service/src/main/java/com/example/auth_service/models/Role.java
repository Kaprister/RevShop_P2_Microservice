package com.example.auth_service.models;

public enum Role {
    ADMIN,
    SELLER,
    BUYER
}
